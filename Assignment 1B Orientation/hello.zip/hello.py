# My very first program to display Hello World on screen
# Name: Neeraav Ranjit
# Student Number: RNJNEE001
# Date: 29 February 2024

print ("Hello World")