# A very tired and struggling NEeraav Ranjit
#21/04/2024
#The push utils for 2048

def push_up(grid):

    for j in range(len(grid[0])):
        for i in range(1, len(grid)):
            if grid[i][j] != 0:
                for b in range(i, 0, -1):
                    if grid[b - 1][j] == 0:
                        grid[b - 1][j] = grid[b][j]
                        grid[b][j] = 0
                    elif grid[b - 1][j] == grid[b][j]:
                        grid[b - 1][j] *=2
                        grid[b][j] = 0
                        break

def push_down(grid):
    # Loop through each column
    for i in range(len(grid)):
        # Loop through each row starting from the second-to-last row
        for j in range(len(grid[i]) - 2, -1, -1):
            # Check if the value is not blank
            if grid[j][i] != 0:
                # Move the value downwards as far as possible
                for b in range(j, len(grid) - 1):
                    # If the cell below is blank, swap the values
                    if grid[b + 1][i] == 0:
                        grid[b + 1][i] = grid[b][i]
                        grid[b][i] = 0
                    # If the cell below has a different value, stop
                    elif grid[b + 1][i] != grid[b][i]:
                        break
                    # If the cell below has the same value, merge them
                    elif grid[b + 1][i] == grid[b][i]:
                        grid[b + 1][i] += grid[b][i]
                        grid[b][i] = 0
                        break


def push_left(grid):
    for i in range(len(grid)):
        for j in range(1, len(grid[i])):
            if grid[i][j] != 0:
                for b in range(j, 0, -1):
                    if grid[i][b - 1] == 0:
                        grid[i][b - 1] = grid[i][b]
                        grid[i][b] = 0
                    elif grid[i][b - 1] == grid[i][b]:
                        grid[i][b - 1] *=2
                        grid[i][b] = 0
                        break

def push_right(grid):

    for i in range(len(grid)):
        for j in range(len(grid[i]) - 2, -1, -1):
            if grid[i][j] != 0:
                for b in range(j, len(grid[i]) - 1):
                    if grid[i][b + 1] == 0:
                        grid[i][b + 1] = grid[i][b]
                        grid[i][b] = 0
                    elif grid[i][b + 1] == grid[i][b]:
                        grid[i][b + 1] *=2
                        grid[i][b] = 0
                        break