#Neeraav Ranjit
#25/04/2024
#A program see if a word matches a word with the ? and * wildcards

def match(word,pattern):
    #base cases
    if len(pattern) == 0 and len(word) == 0:
        return True
    elif len(pattern) == 0 and len(word)!= 0:
        return False
    elif len(pattern) != 0 and len(word) == 0:
        return False
    #check if pattern contains a * or not
    elif pattern[0] == '*' and len(word) == 0:
        return True
    else:
        #sortring out the * cases
        if pattern[0] == '*':
            #matching rest of pattern to word, or pattern to rest of word
            return match(word, pattern[1:]) or match(word[1:], pattern)

        #sorting out the > cases. pretty much just a copy of simple match but me not being a peabrain and remembering how boolean algebra works
        elif pattern[0] == '?' or pattern[0] == word[0]:
            return match(word[1:], pattern[1:])
        else:
            return False
